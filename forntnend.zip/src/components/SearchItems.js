import React, { useState } from 'react';

const SearchItems = () => {
  const [mainCategory, setMainCategory] = useState('');
  const [subCategory, setSubCategory] = useState('');
  const [results, setResults] = useState([]);
  const [error, setError] = useState('');

  const handleSearch = async (e) => {
    e.preventDefault();

    const filters = [];
    if (mainCategory) {
      filters.push({ mainCategory, subCategory: subCategory || '' });
    } else if (subCategory) {
      filters.push({ mainCategory: '', subCategory });
    } else {
      filters.push({ mainCategory: '', subCategory: '' }); // Empty search for all items
    }

    try {
      const response = await fetch('http://localhost:8080/api/items/filter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(filters),
      });

      if (!response.ok) {
        throw new Error('Failed to fetch items');
      }

      const data = await response.json();
      if (data.length === 0) {
        setError('No items found');
        setResults([]);
      } else {
        setResults(data);
        setError('');
      }
    } catch (err) {
      setError(err.message);
      setResults([]);
    }
  };

  return (
    <div style={styles.container}>
      <h2>Search Items</h2>
      <form onSubmit={handleSearch} style={styles.form}>
        <input
          type="text"
          value={mainCategory}
          onChange={(e) => setMainCategory(e.target.value)}
          placeholder="Main Category"
          style={styles.input}
        />
        <input
          type="text"
          value={subCategory}
          onChange={(e) => setSubCategory(e.target.value)}
          placeholder="Sub-Category"
          style={styles.input}
        />
        <button type="submit" style={styles.button}>Search</button>
      </form>
      {error && <p style={styles.error}>{error}</p>}
      <div style={styles.results}>
        {results.map((item) => (
          <div key={item.itemId} style={styles.resultCard}>
            <p><strong>ID:</strong> {item.itemId}</p>
            <p><strong>Description:</strong> {item.iDescription}</p>
            <p><strong>Main Category:</strong> {item.mainCategory}</p>
            <p><strong>Sub-Category:</strong> {item.subCategory}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

const styles = {
  container: {
    width: '400px',
    margin: '50px auto',
    textAlign: 'center',
    padding: '20px',
    border: '1px solid #ccc',
    borderRadius: '10px',
    backgroundColor: '#f9f9f9',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
  },
  input: {
    padding: '8px',
    fontSize: '14px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    width: '100%',
  },
  button: {
    padding: '10px',
    fontSize: '16px',
    color: '#fff',
    backgroundColor: '#007bff',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
  },
  error: {
    color: 'red',
    marginTop: '10px',
  },
  results: {
    marginTop: '20px',
  },
  resultCard: {
    border: '1px solid #ddd',
    borderRadius: '5px',
    padding: '10px',
    marginBottom: '10px',
    textAlign: 'left',
  },
};

export default SearchItems;
