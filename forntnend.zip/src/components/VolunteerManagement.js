import React, { useState, useEffect } from 'react';

const VolunteerManagement = () => {
  const [volunteers, setVolunteers] = useState([]);
  const [newVolunteer, setNewVolunteer] = useState({
    userName: '',
    roleID: '',
  });
  const [roles, setRoles] = useState([]);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    fetchVolunteers();
    fetchRoles();
  }, []);

  const fetchVolunteers = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/volunteers'); // Replace with your backend endpoint
      if (!response.ok) throw new Error('Failed to fetch volunteers');
      const data = await response.json();
      setVolunteers(data);
    } catch (err) {
      setError(err.message);
    }
  };

  const fetchRoles = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/roles'); // Replace with your backend endpoint
      if (!response.ok) throw new Error('Failed to fetch roles');
      const data = await response.json();
      setRoles(data);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewVolunteer({ ...newVolunteer, [name]: value });
  };

  const handleAddVolunteer = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:8080/api/volunteers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newVolunteer),
      });
      if (!response.ok) throw new Error('Failed to add volunteer');
      setSuccess('Volunteer added successfully');
      setError('');
      fetchVolunteers();
      setNewVolunteer({
        userName: '',
        roleID: '',
      });
    } catch (err) {
      setError(err.message);
      setSuccess('');
    }
  };

  const handleDeleteVolunteer = async (userName, roleID) => {
    try {
      const response = await fetch(`http://localhost:8080/api/volunteers/${userName}/${roleID}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error('Failed to delete volunteer');
      setSuccess('Volunteer deleted successfully');
      setError('');
      fetchVolunteers();
    } catch (err) {
      setError(err.message);
      setSuccess('');
    }
  };

  return (
    <div style={styles.container}>
      <h2>Volunteer Management</h2>
      {error && <p style={styles.error}>{error}</p>}
      {success && <p style={styles.success}>{success}</p>}
      <form onSubmit={handleAddVolunteer} style={styles.form}>
        <input
          type="text"
          name="userName"
          placeholder="Volunteer Username"
          value={newVolunteer.userName}
          onChange={handleChange}
          required
        />
        <select
          name="roleID"
          value={newVolunteer.roleID}
          onChange={handleChange}
          required
        >
          <option value="" disabled>
            Select Role
          </option>
          {roles.map((role) => (
            <option key={role.roleID} value={role.roleID}>
              {role.rDescription}
            </option>
          ))}
        </select>
        <button type="submit">Add Volunteer</button>
      </form>
      <h3>Existing Volunteers</h3>
      <table style={styles.table}>
        <thead>
          <tr>
            <th>Username</th>
            <th>Role</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {volunteers.map((volunteer) => (
            <tr key={`${volunteer.userName}-${volunteer.roleID}`}>
              <td>{volunteer.userName}</td>
              <td>{volunteer.roleID}</td>
              <td>
                <button
                  onClick={() => handleDeleteVolunteer(volunteer.userName, volunteer.roleID)}
                  style={styles.deleteButton}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const styles = {
  container: { padding: '20px', textAlign: 'center' },
  error: { color: 'red' },
  success: { color: 'green' },
  form: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '10px', margin: '20px 0' },
  table: {
    width: '80%',
    margin: '20px auto',
    borderCollapse: 'collapse',
    textAlign: 'left',
  },
  deleteButton: {
    backgroundColor: 'red',
    color: 'white',
    border: 'none',
    padding: '5px 10px',
    cursor: 'pointer',
    borderRadius: '4px',
  },
};

export default VolunteerManagement;
