import React, { useState, useEffect } from 'react';

const ManageDonations = () => {
  const [donations, setDonations] = useState([]);
  const [error, setError] = useState('');

  // Fetch all donations on component mount
  useEffect(() => {
    const fetchDonations = async () => {
      try {
        const response = await fetch('http://localhost:8080/api/donations');
        if (!response.ok) {
          throw new Error('Failed to fetch donations');
        }
        const data = await response.json();
        setDonations(data);
      } catch (err) {
        setError(err.message);
      }
    };

    fetchDonations();
  }, []);

  // Handle donation deletion
  const handleDelete = async (itemID, userName) => {
    try {
      const response = await fetch(`http://localhost:8080/api/donations/${itemID}/${userName}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        alert('Donation record deleted successfully!');
        setDonations(donations.filter((donation) => donation.itemID !== itemID || donation.userName !== userName));
      } else {
        alert('Failed to delete donation');
      }
    } catch (err) {
      alert('Error deleting donation: ' + err.message);
    }
  };

  return (
    <div>
      <h2>Manage Donations</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <table>
        <thead>
          <tr>
            <th>Item ID</th>
            <th>User Name</th>
            <th>Donate Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {donations.map((donation) => (
            <tr key={`${donation.itemID}-${donation.userName}`}>
              <td>{donation.itemID}</td>
              <td>{donation.userName}</td>
              <td>{donation.donateDate}</td>
              <td>
                <button onClick={() => handleDelete(donation.itemID, donation.userName)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ManageDonations;
