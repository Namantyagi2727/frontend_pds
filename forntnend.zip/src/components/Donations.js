import React, { useState, useEffect } from 'react';

const Donations = () => {
    const [formData, setFormData] = useState({
        itemID: '',
        userName: '',
        donateDate: '',
        mainCategory: '',
        subCategory: '',
    });
    const [categories, setCategories] = useState([]);
    const [subCategories, setSubCategories] = useState([]);
    const [message, setMessage] = useState('');

    // Fetch categories from the backend on component mount
    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const response = await fetch('http://localhost:8080/api/categories');
                if (!response.ok) {
                    throw new Error('Failed to fetch categories');
                }
                const data = await response.json();
                setCategories(data);
            } catch (error) {
                console.error('Error fetching categories:', error);
            }
        };

        fetchCategories();
    }, []);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });

        // Populate subcategories based on selected mainCategory
        if (name === 'mainCategory') {
            const selectedCategory = categories.find((cat) => cat.mainCategory === value);
            setSubCategories(selectedCategory ? selectedCategory.subCategories : []);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch('http://localhost:8080/api/donations/madeADonation', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData),
            });

            if (response.ok) {
                setMessage('Donation added successfully!');
                setFormData({
                    itemID: '',
                    userName: '',
                    donateDate: '',
                    mainCategory: '',
                    subCategory: '',
                });
                setSubCategories([]);
            } else {
                const errorText = await response.text();
                setMessage(`Failed to add donation: ${errorText}`);
            }
        } catch (error) {
            setMessage(`Error: ${error.message}`);
        }
    };

    return (
        <div style={styles.container}>
            <h2>Make a Donation</h2>
            <form onSubmit={handleSubmit} style={styles.form}>
                <input
                    type="text"
                    name="itemID"
                    placeholder="Item ID"
                    value={formData.itemID}
                    onChange={handleChange}
                    required
                />
                <input
                    type="text"
                    name="userName"
                    placeholder="Your Username"
                    value={formData.userName}
                    onChange={handleChange}
                    required
                />
                <input
                    type="date"
                    name="donateDate"
                    placeholder="Donation Date"
                    value={formData.donateDate}
                    onChange={handleChange}
                    required
                />
                <select
                    name="mainCategory"
                    value={formData.mainCategory}
                    onChange={handleChange}
                    required
                >
                    <option value="" disabled>
                        Select Main Category
                    </option>
                    {categories.map((cat) => (
                        <option key={cat.mainCategory} value={cat.mainCategory}>
                            {cat.mainCategory}
                        </option>
                    ))}
                </select>
                <select
                    name="subCategory"
                    value={formData.subCategory}
                    onChange={handleChange}
                    required
                >
                    <option value="" disabled>
                        Select Sub Category
                    </option>
                    {subCategories.map((subCat) => (
                        <option key={subCat} value={subCat}>
                            {subCat}
                        </option>
                    ))}
                </select>
                <button type="submit" style={styles.button}>
                    Donate
                </button>
            </form>
            {message && <p style={styles.message}>{message}</p>}
        </div>
    );
};

const styles = {
    container: {
        width: '400px',
        margin: '50px auto',
        padding: '20px',
        border: '1px solid #ccc',
        borderRadius: '10px',
        backgroundColor: '#f9f9f9',
    },
    form: {
        display: 'flex',
        flexDirection: 'column',
        gap: '10px',
    },
    button: {
        padding: '10px',
        fontSize: '16px',
        color: '#fff',
        backgroundColor: '#007bff',
        border: 'none',
        borderRadius: '5px',
        cursor: 'pointer',
    },
    message: {
        marginTop: '10px',
        color: 'green',
    },
};

export default Donations;
