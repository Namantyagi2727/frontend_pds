import React, { useState, useEffect } from 'react';

const LocationManagement = () => {
  const [locations, setLocations] = useState([]);
  const [newLocation, setNewLocation] = useState({
    roomNum: '',
    shelfNum: '',
    shelf: '',
    shelfDescription: '',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    fetchLocations();
  }, []);

  const fetchLocations = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/locations'); // Replace with the actual endpoint
      if (!response.ok) throw new Error('Failed to fetch locations');
      const data = await response.json();
      setLocations(data);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewLocation({ ...newLocation, [name]: value });
  };

  const handleAddLocation = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:8080/api/locations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newLocation),
      });
      if (!response.ok) throw new Error('Failed to add location');
      setSuccess('Location added successfully');
      setError('');
      fetchLocations();
      setNewLocation({ roomNum: '', shelfNum: '', shelf: '', shelfDescription: '' });
    } catch (err) {
      setError(err.message);
      setSuccess('');
    }
  };

  return (
    <div style={styles.container}>
      <h2>Location Management</h2>
      {error && <p style={styles.error}>{error}</p>}
      {success && <p style={styles.success}>{success}</p>}
      <form onSubmit={handleAddLocation} style={styles.form}>
        <input
          type="text"
          name="roomNum"
          placeholder="Room Number"
          value={newLocation.roomNum}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="shelfNum"
          placeholder="Shelf Number"
          value={newLocation.shelfNum}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="shelf"
          placeholder="Shelf"
          value={newLocation.shelf}
          onChange={handleChange}
        />
        <input
          type="text"
          name="shelfDescription"
          placeholder="Shelf Description"
          value={newLocation.shelfDescription}
          onChange={handleChange}
        />
        <button type="submit">Add Location</button>
      </form>
      <h3>Existing Locations</h3>
      <table style={styles.table}>
        <thead>
          <tr>
            <th>Room Number</th>
            <th>Shelf Number</th>
            <th>Shelf</th>
            <th>Description</th>
          </tr>
        </thead>
        <tbody>
          {locations.map((location) => (
            <tr key={`${location.roomNum}-${location.shelfNum}`}>
              <td>{location.roomNum}</td>
              <td>{location.shelfNum}</td>
              <td>{location.shelf}</td>
              <td>{location.shelfDescription}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const styles = {
  container: { padding: '20px', textAlign: 'center' },
  error: { color: 'red' },
  success: { color: 'green' },
  form: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '10px', margin: '20px 0' },
  table: {
    width: '80%',
    margin: '20px auto',
    borderCollapse: 'collapse',
    textAlign: 'left',
  },
  th: { borderBottom: '2px solid #ddd', padding: '10px' },
  td: { borderBottom: '1px solid #ddd', padding: '10px' },
};

export default LocationManagement;
