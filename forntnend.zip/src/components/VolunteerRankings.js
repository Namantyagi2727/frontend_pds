import React, { useState, useEffect } from 'react';

const VolunteerRankings = () => {
  const [rankings, setRankings] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchRankings();
  }, []);

  const fetchRankings = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/volunteer-rankings'); // Replace with actual endpoint
      if (!response.ok) throw new Error('Failed to fetch rankings');
      const data = await response.json();
      setRankings(data);
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div style={styles.container}>
      <h2>Volunteer Rankings</h2>
      {error && <p style={styles.error}>{error}</p>}
      <table style={styles.table}>
        <thead>
          <tr>
            <th>Rank</th>
            <th>Volunteer</th>
            <th>Points</th>
          </tr>
        </thead>
        <tbody>
          {rankings.map((volunteer, index) => (
            <tr key={volunteer.userName}>
              <td>{index + 1}</td>
              <td>{volunteer.userName}</td>
              <td>{volunteer.points}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const styles = {
  container: { padding: '20px', textAlign: 'center' },
  error: { color: 'red' },
  table: {
    width: '80%',
    margin: '20px auto',
    borderCollapse: 'collapse',
    textAlign: 'left',
  },
  th: { border: '1px solid #ccc', padding: '10px', backgroundColor: '#f4f4f4' },
  td: { border: '1px solid #ccc', padding: '10px' },
};

export default VolunteerRankings;
