import React, { useState, useEffect } from 'react';

const PieceManagement = () => {
  const [pieces, setPieces] = useState([]);
  const [newPiece, setNewPiece] = useState({
    itemID: '',
    pieceNum: '',
    pDescription: '',
    length: '',
    width: '',
    height: '',
    roomNum: '',
    shelfNum: '',
    pNotes: '',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    fetchPieces();
  }, []);

  const fetchPieces = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/pieces'); // Replace with the actual endpoint
      if (!response.ok) throw new Error('Failed to fetch pieces');
      const data = await response.json();
      setPieces(data);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewPiece({ ...newPiece, [name]: value });
  };

  const handleAddPiece = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:8080/api/pieces', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newPiece),
      });
      if (!response.ok) throw new Error('Failed to add piece');
      setSuccess('Piece added successfully');
      setError('');
      fetchPieces();
      setNewPiece({
        itemID: '',
        pieceNum: '',
        pDescription: '',
        length: '',
        width: '',
        height: '',
        roomNum: '',
        shelfNum: '',
        pNotes: '',
      });
    } catch (err) {
      setError(err.message);
      setSuccess('');
    }
  };

  const handleDeletePiece = async (itemID, pieceNum) => {
    try {
      const response = await fetch(`http://localhost:8080/api/pieces/${itemID}/${pieceNum}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error('Failed to delete piece');
      setSuccess('Piece deleted successfully');
      setError('');
      fetchPieces();
    } catch (err) {
      setError(err.message);
      setSuccess('');
    }
  };

  return (
    <div style={styles.container}>
      <h2>Piece Management</h2>
      {error && <p style={styles.error}>{error}</p>}
      {success && <p style={styles.success}>{success}</p>}
      <form onSubmit={handleAddPiece} style={styles.form}>
        <input
          type="text"
          name="itemID"
          placeholder="Item ID"
          value={newPiece.itemID}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="pieceNum"
          placeholder="Piece Number"
          value={newPiece.pieceNum}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="pDescription"
          placeholder="Description"
          value={newPiece.pDescription}
          onChange={handleChange}
        />
        <input
          type="number"
          name="length"
          placeholder="Length"
          value={newPiece.length}
          onChange={handleChange}
          required
        />
        <input
          type="number"
          name="width"
          placeholder="Width"
          value={newPiece.width}
          onChange={handleChange}
          required
        />
        <input
          type="number"
          name="height"
          placeholder="Height"
          value={newPiece.height}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="roomNum"
          placeholder="Room Number"
          value={newPiece.roomNum}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="shelfNum"
          placeholder="Shelf Number"
          value={newPiece.shelfNum}
          onChange={handleChange}
          required
        />
        <textarea
          name="pNotes"
          placeholder="Notes"
          value={newPiece.pNotes}
          onChange={handleChange}
        />
        <button type="submit">Add Piece</button>
      </form>
      <h3>Existing Pieces</h3>
      <table style={styles.table}>
        <thead>
          <tr>
            <th>Item ID</th>
            <th>Piece Number</th>
            <th>Description</th>
            <th>Length</th>
            <th>Width</th>
            <th>Height</th>
            <th>Room</th>
            <th>Shelf</th>
            <th>Notes</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {pieces.map((piece) => (
            <tr key={`${piece.itemID}-${piece.pieceNum}`}>
              <td>{piece.itemID}</td>
              <td>{piece.pieceNum}</td>
              <td>{piece.pDescription}</td>
              <td>{piece.length}</td>
              <td>{piece.width}</td>
              <td>{piece.height}</td>
              <td>{piece.roomNum}</td>
              <td>{piece.shelfNum}</td>
              <td>{piece.pNotes}</td>
              <td>
                <button
                  onClick={() => handleDeletePiece(piece.itemID, piece.pieceNum)}
                  style={styles.deleteButton}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const styles = {
  container: { padding: '20px', textAlign: 'center' },
  error: { color: 'red' },
  success: { color: 'green' },
  form: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '10px', margin: '20px 0' },
  table: {
    width: '80%',
    margin: '20px auto',
    borderCollapse: 'collapse',
    textAlign: 'left',
  },
  deleteButton: {
    backgroundColor: 'red',
    color: 'white',
    border: 'none',
    padding: '5px 10px',
    cursor: 'pointer',
    borderRadius: '4px',
  },
};

export default PieceManagement;
