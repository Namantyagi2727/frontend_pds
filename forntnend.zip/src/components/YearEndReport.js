import React, { useEffect, useState } from 'react';
import axios from 'axios';

const YearEndReport = () => {
  const [reportData, setReportData] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Replace with the correct API endpoint
    axios
      .get('/api/reports/year-end')
      .then((response) => {
        setReportData(response.data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  if (loading) return <p>Loading Year-End Report...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div>
      <h1>Year-End Report</h1>
      <p><strong>Clients Served:</strong> {reportData.clientsServed}</p>
      <p><strong>Items Donated:</strong></p>
      <ul>
        {reportData.itemsDonated?.map((item) => (
          <li key={item.category}>
            {item.category}: {item.count}
          </li>
        ))}
      </ul>
      <p><strong>Additional Statistics:</strong></p>
      <p>{reportData.additionalStats}</p>
    </div>
  );
};

export default YearEndReport;
