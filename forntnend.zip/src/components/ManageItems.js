import React, { useState, useEffect } from 'react';

const ManageItems = () => {
  const [items, setItems] = useState([]);
  const [newItem, setNewItem] = useState({
    iDescription: '',
    photo: '',
    color: '',
    isNew: true,
    hasPieces: false,
    material: '',
    mainCategory: '',
    subCategory: '',
  });
  const [error, setError] = useState('');

  // Fetch all items on component mount
  useEffect(() => {
    const fetchItems = async () => {
      try {
        const response = await fetch('http://localhost:8080/api/items');
        if (!response.ok) {
          throw new Error('Failed to fetch items');
        }
        const data = await response.json();
        setItems(data);
      } catch (err) {
        setError(err.message);
      }
    };

    fetchItems();
  }, []);

  // Handle item addition
  const handleAddItem = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:8080/api/items', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newItem),
      });

      if (response.ok) {
        const addedItem = await response.json();
        setItems([...items, addedItem]);
        alert('Item added successfully!');
        setNewItem({
          iDescription: '',
          photo: '',
          color: '',
          isNew: true,
          hasPieces: false,
          material: '',
          mainCategory: '',
          subCategory: '',
        });
      } else {
        alert('Failed to add item');
      }
    } catch (err) {
      alert('Error adding item: ' + err.message);
    }
  };

  // Handle item deletion
  const handleDeleteItem = async (itemID) => {
    try {
      const response = await fetch(`http://localhost:8080/api/items/${itemID}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        setItems(items.filter((item) => item.itemID !== itemID));
        alert('Item deleted successfully!');
      } else {
        alert('Failed to delete item');
      }
    } catch (err) {
      alert('Error deleting item: ' + err.message);
    }
  };

  return (
    <div>
      <h2>Manage Items</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}

      {/* Add Item Form */}
      <form onSubmit={handleAddItem}>
        <h3>Add New Item</h3>
        <input
          type="text"
          name="iDescription"
          placeholder="Description"
          value={newItem.iDescription}
          onChange={(e) => setNewItem({ ...newItem, iDescription: e.target.value })}
          required
        />
        <input
          type="text"
          name="photo"
          placeholder="Photo URL"
          value={newItem.photo}
          onChange={(e) => setNewItem({ ...newItem, photo: e.target.value })}
        />
        <input
          type="text"
          name="color"
          placeholder="Color"
          value={newItem.color}
          onChange={(e) => setNewItem({ ...newItem, color: e.target.value })}
        />
        <select
          name="isNew"
          value={newItem.isNew}
          onChange={(e) => setNewItem({ ...newItem, isNew: e.target.value === 'true' })}
        >
          <option value="true">New</option>
          <option value="false">Used</option>
        </select>
        <select
          name="hasPieces"
          value={newItem.hasPieces}
          onChange={(e) => setNewItem({ ...newItem, hasPieces: e.target.value === 'true' })}
        >
          <option value="false">No Pieces</option>
          <option value="true">Has Pieces</option>
        </select>
        <input
          type="text"
          name="material"
          placeholder="Material"
          value={newItem.material}
          onChange={(e) => setNewItem({ ...newItem, material: e.target.value })}
        />
        <input
          type="text"
          name="mainCategory"
          placeholder="Main Category"
          value={newItem.mainCategory}
          onChange={(e) => setNewItem({ ...newItem, mainCategory: e.target.value })}
        />
        <input
          type="text"
          name="subCategory"
          placeholder="Sub Category"
          value={newItem.subCategory}
          onChange={(e) => setNewItem({ ...newItem, subCategory: e.target.value })}
        />
        <button type="submit">Add Item</button>
      </form>

      {/* Item List */}
      <h3>Item List</h3>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Description</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => (
            <tr key={item.itemID}>
              <td>{item.itemID}</td>
              <td>{item.iDescription}</td>
              <td>
                <button onClick={() => handleDeleteItem(item.itemID)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ManageItems;
