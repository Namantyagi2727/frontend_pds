import React, { useState, useEffect } from 'react';

const Dashboard = () => {
  const [stats, setStats] = useState({});
  const [error, setError] = useState('');

  useEffect(() => {
    fetchDashboardStats();
  }, []);

  const fetchDashboardStats = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/dashboard/stats'); // Adjust endpoint as necessary
      if (!response.ok) {
        throw new Error('Failed to fetch dashboard stats');
      }
      const data = await response.json();
      setStats(data);
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div>
      <h2>Dashboard</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <div>
        <p><strong>Total Orders:</strong> {stats.totalOrders}</p>
        <p><strong>Delivered Orders:</strong> {stats.deliveredOrders}</p>
        <p><strong>Pending Deliveries:</strong> {stats.pendingDeliveries}</p>
        <p><strong>Total Donations:</strong> {stats.totalDonations}</p>
      </div>
    </div>
  );
};

export default Dashboard;
