import React, { useState, useEffect } from 'react';

const ManageRoles = () => {
  const [roles, setRoles] = useState([]);
  const [newRole, setNewRole] = useState({ roleID: '', description: '' });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    fetchRoles();
  }, []);

  const fetchRoles = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/roles'); // Replace with actual endpoint
      if (!response.ok) throw new Error('Failed to fetch roles');
      const data = await response.json();
      setRoles(data);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewRole({ ...newRole, [name]: value });
  };

  const handleAddRole = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    try {
      const response = await fetch('http://localhost:8080/api/roles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newRole),
      });
      if (!response.ok) throw new Error('Failed to add role');
      setSuccess('Role added successfully');
      setNewRole({ roleID: '', description: '' });
      fetchRoles(); // Refresh roles list
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div style={styles.container}>
      <h2>Manage Roles</h2>
      {error && <p style={styles.error}>{error}</p>}
      {success && <p style={styles.success}>{success}</p>}
      <div style={styles.rolesList}>
        <h3>Existing Roles</h3>
        <ul>
          {roles.map((role) => (
            <li key={role.roleID}>
              <strong>ID:</strong> {role.roleID}, <strong>Description:</strong> {role.rDescription}
            </li>
          ))}
        </ul>
      </div>
      <div style={styles.addRole}>
        <h3>Add New Role</h3>
        <form onSubmit={handleAddRole}>
          <input
            type="text"
            name="roleID"
            placeholder="Role ID"
            value={newRole.roleID}
            onChange={handleInputChange}
            required
            style={styles.input}
          />
          <input
            type="text"
            name="description"
            placeholder="Description"
            value={newRole.description}
            onChange={handleInputChange}
            style={styles.input}
          />
          <button type="submit" style={styles.button}>Add Role</button>
        </form>
      </div>
    </div>
  );
};

const styles = {
  container: { padding: '20px', textAlign: 'center' },
  error: { color: 'red' },
  success: { color: 'green' },
  rolesList: { margin: '20px 0' },
  addRole: { margin: '20px 0' },
  input: { padding: '10px', margin: '10px 0', width: '200px' },
  button: { padding: '10px 20px', backgroundColor: '#007bff', color: '#fff', border: 'none', cursor: 'pointer' },
};

export default ManageRoles;
