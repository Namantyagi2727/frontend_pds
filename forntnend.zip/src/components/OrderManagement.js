import React, { useState, useEffect } from 'react';

const OrderManagement = () => {
  const [orders, setOrders] = useState([]);
  const [newOrder, setNewOrder] = useState({
    orderDate: '',
    orderNotes: '',
    supervisor: '',
    client: '',
  });
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Fetch all orders
  const fetchOrders = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/orders');
      if (response.ok) {
        const data = await response.json();
        setOrders(data);
      } else {
        throw new Error('Failed to fetch orders');
      }
    } catch (err) {
      setError(err.message);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  // Handle input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewOrder((prevOrder) => ({
      ...prevOrder,
      [name]: value,
    }));
  };

  // Submit a new order
  const handleSubmitOrder = async (e) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');
    try {
      const response = await fetch('http://localhost:8080/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newOrder),
      });
      if (response.ok) {
        setSuccessMessage('Order placed successfully!');
        setNewOrder({
          orderDate: '',
          orderNotes: '',
          supervisor: '',
          client: '',
        });
        fetchOrders(); // Refresh the order list
      } else {
        const errorText = await response.text();
        throw new Error(errorText);
      }
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div style={styles.container}>
      <h2>Order Management</h2>

      {/* Form for placing a new order */}
      <form onSubmit={handleSubmitOrder} style={styles.form}>
        <h3>Place a New Order</h3>
        <input
          type="date"
          name="orderDate"
          value={newOrder.orderDate}
          onChange={handleInputChange}
          required
          style={styles.input}
        />
        <input
          type="text"
          name="orderNotes"
          placeholder="Order Notes"
          value={newOrder.orderNotes}
          onChange={handleInputChange}
          style={styles.input}
        />
        <input
          type="text"
          name="supervisor"
          placeholder="Supervisor Username"
          value={newOrder.supervisor}
          onChange={handleInputChange}
          required
          style={styles.input}
        />
        <input
          type="text"
          name="client"
          placeholder="Client Username"
          value={newOrder.client}
          onChange={handleInputChange}
          required
          style={styles.input}
        />
        <button type="submit" style={styles.button}>Place Order</button>
        {successMessage && <p style={styles.success}>{successMessage}</p>}
        {error && <p style={styles.error}>{error}</p>}
      </form>

      {/* List of existing orders */}
      <div style={styles.orders}>
        <h3>Existing Orders</h3>
        {orders.length > 0 ? (
          <table style={styles.table}>
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Date</th>
                <th>Notes</th>
                <th>Supervisor</th>
                <th>Client</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order) => (
                <tr key={order.orderID}>
                  <td>{order.orderID}</td>
                  <td>{order.orderDate}</td>
                  <td>{order.orderNotes}</td>
                  <td>{order.supervisor}</td>
                  <td>{order.client}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No orders found</p>
        )}
      </div>
    </div>
  );
};

const styles = {
  container: {
    width: '600px',
    margin: '50px auto',
    textAlign: 'center',
    padding: '20px',
    border: '1px solid #ccc',
    borderRadius: '10px',
    backgroundColor: '#f9f9f9',
  },
  form: {
    marginBottom: '30px',
  },
  input: {
    display: 'block',
    width: '100%',
    padding: '10px',
    margin: '10px 0',
    border: '1px solid #ccc',
    borderRadius: '5px',
  },
  button: {
    padding: '10px 20px',
    backgroundColor: '#007bff',
    color: '#fff',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
  },
  success: {
    color: 'green',
    marginTop: '10px',
  },
  error: {
    color: 'red',
    marginTop: '10px',
  },
  orders: {
    marginTop: '30px',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
  },
  th: {
    backgroundColor: '#007bff',
    color: '#fff',
    padding: '10px',
    border: '1px solid #ccc',
  },
  td: {
    padding: '10px',
    border: '1px solid #ccc',
  },
};

export default OrderManagement;
