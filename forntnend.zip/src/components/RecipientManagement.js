import React, { useState, useEffect } from 'react';

const RecipientManagement = () => {
  const [recipients, setRecipients] = useState([]);
  const [newRecipient, setNewRecipient] = useState({
    name: '',
    contact: '',
    address: '',
  });
  const [error, setError] = useState('');

  useEffect(() => {
    fetchRecipients();
  }, []);

  const fetchRecipients = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/recipients'); // Adjust endpoint as necessary
      if (!response.ok) {
        throw new Error('Failed to fetch recipients');
      }
      const data = await response.json();
      setRecipients(data);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleAddRecipient = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/recipients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newRecipient),
      });
      if (!response.ok) {
        throw new Error('Failed to add recipient');
      }
      fetchRecipients(); // Refresh recipient list
      setNewRecipient({ name: '', contact: '', address: '' });
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div>
      <h2>Recipient Management</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}

      <h3>Add Recipient</h3>
      <input
        type="text"
        placeholder="Name"
        value={newRecipient.name}
        onChange={(e) => setNewRecipient({ ...newRecipient, name: e.target.value })}
      />
      <input
        type="text"
        placeholder="Contact"
        value={newRecipient.contact}
        onChange={(e) => setNewRecipient({ ...newRecipient, contact: e.target.value })}
      />
      <input
        type="text"
        placeholder="Address"
        value={newRecipient.address}
        onChange={(e) => setNewRecipient({ ...newRecipient, address: e.target.value })}
      />
      <button onClick={handleAddRecipient}>Add Recipient</button>

      <h3>Recipient List</h3>
      <table border="1">
        <thead>
          <tr>
            <th>Name</th>
            <th>Contact</th>
            <th>Address</th>
          </tr>
        </thead>
        <tbody>
          {recipients.map((recipient) => (
            <tr key={recipient.id}>
              <td>{recipient.name}</td>
              <td>{recipient.contact}</td>
              <td>{recipient.address}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default RecipientManagement;
