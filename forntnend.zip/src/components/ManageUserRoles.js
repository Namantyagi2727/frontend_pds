import React, { useState, useEffect } from 'react';

const ManageUserRoles = () => {
  const [users, setUsers] = useState([]);
  const [roles, setRoles] = useState([]);
  const [selectedUser, setSelectedUser] = useState('');
  const [selectedRole, setSelectedRole] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    fetchUsers();
    fetchRoles();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/persons'); // Replace with actual endpoint
      if (!response.ok) throw new Error('Failed to fetch users');
      const data = await response.json();
      setUsers(data);
    } catch (err) {
      setError(err.message);
    }
  };

  const fetchRoles = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/roles'); // Replace with actual endpoint
      if (!response.ok) throw new Error('Failed to fetch roles');
      const data = await response.json();
      setRoles(data);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleAssignRole = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    try {
      const response = await fetch(`http://localhost:8080/api/acts`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userName: selectedUser, roleID: selectedRole }),
      });
      if (!response.ok) throw new Error('Failed to assign role');
      setSuccess(`Role '${selectedRole}' assigned to user '${selectedUser}' successfully`);
      setSelectedUser('');
      setSelectedRole('');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div style={styles.container}>
      <h2>Manage User Roles</h2>
      {error && <p style={styles.error}>{error}</p>}
      {success && <p style={styles.success}>{success}</p>}
      <form onSubmit={handleAssignRole} style={styles.form}>
        <div>
          <label htmlFor="userSelect">Select User:</label>
          <select
            id="userSelect"
            value={selectedUser}
            onChange={(e) => setSelectedUser(e.target.value)}
            required
            style={styles.select}
          >
            <option value="" disabled>Select a user</option>
            {users.map((user) => (
              <option key={user.userName} value={user.userName}>
                {user.userName} ({user.fname} {user.lname})
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="roleSelect">Select Role:</label>
          <select
            id="roleSelect"
            value={selectedRole}
            onChange={(e) => setSelectedRole(e.target.value)}
            required
            style={styles.select}
          >
            <option value="" disabled>Select a role</option>
            {roles.map((role) => (
              <option key={role.roleID} value={role.roleID}>
                {role.roleID} - {role.rDescription}
              </option>
            ))}
          </select>
        </div>
        <button type="submit" style={styles.button}>Assign Role</button>
      </form>
    </div>
  );
};

const styles = {
  container: { padding: '20px', textAlign: 'center' },
  error: { color: 'red' },
  success: { color: 'green' },
  form: { display: 'flex', flexDirection: 'column', gap: '15px', alignItems: 'center' },
  select: { padding: '10px', width: '250px', margin: '10px 0' },
  button: { padding: '10px 20px', backgroundColor: '#007bff', color: '#fff', border: 'none', cursor: 'pointer' },
};

export default ManageUserRoles;
