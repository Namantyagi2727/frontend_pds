import React, { useState, useEffect } from 'react';

const ManageUsers = () => {
  const [users, setUsers] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/persons'); // Replace with your actual API endpoint
      if (!response.ok) throw new Error('Failed to fetch users');
      const data = await response.json();
      setUsers(data);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleDelete = async (userName) => {
    if (!window.confirm('Are you sure you want to delete this user?')) return;
    try {
      const response = await fetch(`http://localhost:8080/api/persons/${userName}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error('Failed to delete user');
      alert('User deleted successfully!');
      setUsers(users.filter((user) => user.userName !== userName));
    } catch (err) {
      alert('Error deleting user: ' + err.message);
    }
  };

  return (
    <div style={styles.container}>
      <h2>Manage Users</h2>
      {error && <p style={styles.error}>{error}</p>}
      {users.length === 0 && !error && <p>No users found.</p>}
      <table style={styles.table}>
        <thead>
          <tr>
            <th>Username</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.userName}>
              <td>{user.userName}</td>
              <td>{user.fname}</td>
              <td>{user.lname}</td>
              <td>{user.email}</td>
              <td>{user.role}</td>
              <td>
                <button
                  style={styles.deleteButton}
                  onClick={() => handleDelete(user.userName)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const styles = {
  container: { padding: '20px', textAlign: 'center' },
  error: { color: 'red' },
  table: { width: '100%', borderCollapse: 'collapse', marginTop: '20px' },
  deleteButton: {
    backgroundColor: '#ff4d4d',
    color: 'white',
    border: 'none',
    padding: '5px 10px',
    cursor: 'pointer',
    borderRadius: '5px',
  },
};

export default ManageUsers;
